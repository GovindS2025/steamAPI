package com.example;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class distinct4 {
    List<String> words = Arrays.asList("one", "two", "three", "four", "five", "one", "two");
    List<String> result = words.stream()
            .distinct() // Remove duplicates
            .collect(Collectors.toList());

    public static void main(String[] args) {
        distinct4 example = new distinct4();
        System.out.println("Distinct words: " + example.result);
    }
}
