package com.example;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

public class Flatmap2 {
// Flatten a list of lists into a single list
    List<List<String>> listOfLists = Arrays.asList(

            Arrays.asList("one", "two", "three"),
            Arrays.asList("four", "five"),
            Arrays.asList("six", "seven", "eight"),
            Arrays.asList("nine", "ten")

    );
List<String> flatList = listOfLists.stream()
            .flatMap(Collection::stream)
        .collect(Collectors.toList());
    public static void main(String[] args) {
        Flatmap2 example = new Flatmap2();
        System.out.println("Flattened list: " + example.flatList);
    }

}
