package com.example;

import javax.swing.*;

public final class Operation {

    public final boolean myFun(int a, int b) {

        if (a == b) {
            System.out.println("Both numbers are equal");
        } else {
            System.out.println("Both numbers are not equal");
        }
        return true;
    }
    public boolean myFun2(int a, int b) {

        if (a == b) {
            System.out.println("Both numbers are equal");
        } else {
            System.out.println("Both numbers are not equal");
        }
        return true;
    }
    public class MyClass {


        public  void chield(String[] args) {
            //operation op = new operation();

            System.out.println(myFun(20,30));
        }
    }
}



