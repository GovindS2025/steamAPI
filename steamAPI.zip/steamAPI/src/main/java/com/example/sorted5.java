package com.example;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class sorted5 {
    // Sort a list of integers in ascending order
    // Example list of integers
    List<String> names = Arrays.asList("Dany", "Charlie", "Eline", "Bravo", "Arav");
    List<String> result = names.stream()
            .sorted()
            .collect(Collectors.toList());
    // Using sorted to sort the list

    public static void main(String[] args) {
        sorted5 example = new sorted5();
        System.out.println("Sorted numbers: " + example.result);
    }
}
