package com.example;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class peek6 {
    //print each element and convert to uppercase
    List<String> words = Arrays.asList("1", "2", "3", "4", "5");
    List<String> result = words.stream()
            .sorted(Comparator.reverseOrder())
            .collect(Collectors.toList());


    public static void main(String[] args) {
        peek6 example = new peek6();
        System.out.println("reverse order: " + example.result);
    }
}
