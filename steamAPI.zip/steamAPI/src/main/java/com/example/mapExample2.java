package com.example;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class mapExample2 {

    //Transform a list int a list of their uppercase version
    List<String> words = Arrays.asList("one", "two", "three", "four", "five");
    List<String> result = words.stream()
            .map(String::toUpperCase)
            .collect(Collectors.toList());

    public static void main(String[] args) {
        mapExample2 example = new mapExample2();
        System.out.println("Uppercase words: " + example.result);
    }

}
